package org.mods.app.stormcenter;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.app.Activity;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


/**
 * Created by Matthew on 7/13/2015.
 */

public class Omniglobe extends Activity {
    TextView txt;
    Button seaTerm;
    Button seaTermssa;
    Button seaTermsst;
    Button seaTermiso;
    Button seaTermmodis;
    Button carbonFlux;
    Button blackCarbon;
    Button carbonSulfate;
    Button opticalThick;
    Button acars;
    Button ganymede;
    Button io;
    Button callisto;
    Button triton;
    ImageView empty;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.omniglobe);
        seaTerm = (Button) findViewById(R.id.seaTerm);
        seaTermssa = (Button) findViewById(R.id.seaTermssa);
        txt = (TextView) findViewById(R.id.txt);
        seaTermsst = (Button) findViewById(R.id.seaTermsst);
        seaTermiso = (Button) findViewById(R.id.seaTermiso);
        seaTermmodis = (Button) findViewById(R.id.seaTermmodis);
        carbonFlux = (Button) findViewById(R.id.cFlux);
        blackCarbon = (Button) findViewById(R.id.bCarbon);
        carbonSulfate = (Button) findViewById(R.id.carbonSulfate);
        opticalThick = (Button) findViewById(R.id.opticalthick);
        acars = (Button) findViewById(R.id.acars);
        ganymede = (Button) findViewById(R.id.ganymede);
        io = (Button) findViewById(R.id.io);
        callisto = (Button) findViewById(R.id.callisto);
        triton = (Button) findViewById(R.id.triton);
        empty = (ImageView) findViewById(R.id.empty);
    }

    public void scale(View view) {
        txt.setText(R.string.aboutglobe);
        txt.setVisibility(View.VISIBLE);
        seaTerm.setVisibility(View.INVISIBLE);
        empty.setVisibility(View.INVISIBLE);
        seaTermssa.setVisibility(View.INVISIBLE);
        seaTermsst.setVisibility(View.INVISIBLE);
        seaTermiso.setVisibility(View.INVISIBLE);
        seaTermmodis.setVisibility(View.INVISIBLE);
        carbonFlux.setVisibility(View.INVISIBLE);
        blackCarbon.setVisibility(View.INVISIBLE);
        carbonSulfate.setVisibility(View.INVISIBLE);
        opticalThick.setVisibility(View.INVISIBLE);
        acars.setVisibility(View.INVISIBLE);
        ganymede.setVisibility(View.INVISIBLE);
        io.setVisibility(View.INVISIBLE);
        callisto.setVisibility(View.INVISIBLE);
        triton.setVisibility(View.INVISIBLE);
    }

    public void displaySea(View view) {
        seaTerm.setVisibility(View.VISIBLE);
        seaTermssa.setVisibility(View.VISIBLE);
        seaTermsst.setVisibility(View.VISIBLE);
        seaTermiso.setVisibility(View.VISIBLE);
        seaTermmodis.setVisibility(View.VISIBLE);
        txt.setVisibility(View.INVISIBLE);
        empty.setVisibility(View.INVISIBLE);
        carbonFlux.setVisibility(View.INVISIBLE);
        blackCarbon.setVisibility(View.INVISIBLE);
        carbonSulfate.setVisibility(View.INVISIBLE);
        opticalThick.setVisibility(View.INVISIBLE);
        acars.setVisibility(View.INVISIBLE);
        ganymede.setVisibility(View.INVISIBLE);
        io.setVisibility(View.INVISIBLE);
        callisto.setVisibility(View.INVISIBLE);
        triton.setVisibility(View.INVISIBLE);
        //txt.setText(R.string.btn_omnig);
    }

    public void displayAtm(View view) {

        //txt.setText(R.string.btn_omnigl);
        seaTerm.setVisibility(View.INVISIBLE);
        seaTermssa.setVisibility(View.INVISIBLE);
        seaTermsst.setVisibility(View.INVISIBLE);
        seaTermiso.setVisibility(View.INVISIBLE);
        seaTermmodis.setVisibility(View.INVISIBLE);
        empty.setVisibility(View.INVISIBLE);
        carbonFlux.setVisibility(View.VISIBLE);
        txt.setVisibility(View.INVISIBLE);
        blackCarbon.setVisibility(View.VISIBLE);
        carbonSulfate.setVisibility(View.VISIBLE);
        opticalThick.setVisibility(View.VISIBLE);
        acars.setVisibility(View.VISIBLE);
        ganymede.setVisibility(View.INVISIBLE);
        io.setVisibility(View.INVISIBLE);
        callisto.setVisibility(View.INVISIBLE);
        triton.setVisibility(View.INVISIBLE);
    }
    public void displaySolar(View View) {
        txt.setVisibility(View.INVISIBLE);
        empty.setVisibility(View.INVISIBLE);
        seaTerm.setVisibility(View.INVISIBLE);
        seaTermssa.setVisibility(View.INVISIBLE);
        seaTermsst.setVisibility(View.INVISIBLE);
        seaTermiso.setVisibility(View.INVISIBLE);
        seaTermmodis.setVisibility(View.INVISIBLE);
        carbonFlux.setVisibility(View.INVISIBLE);
        blackCarbon.setVisibility(View.INVISIBLE);
        carbonSulfate.setVisibility(View.INVISIBLE);
        opticalThick.setVisibility(View.INVISIBLE);
        acars.setVisibility(View.INVISIBLE);
        ganymede.setVisibility(View.VISIBLE);
        io.setVisibility(View.VISIBLE);
        callisto.setVisibility(View.VISIBLE);
        triton.setVisibility(View.VISIBLE);
    }

    public void conveyorBelt(View View){
        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.AlertDialogCustom));
        builder.setMessage(R.string.conveyor_belt)
                .setTitle("Ocean conveyor belt");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.conveyorbelt);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void seaSurface(View View){
        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.AlertDialogCustom));
        builder.setMessage(R.string.ssa)
                .setTitle("Sea Surface Anamoly");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.anamoly);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void sst(View View){
        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.AlertDialogCustom));
        builder.setMessage("Sea Surface Temperatures")
                .setTitle("SST");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.sst);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void isotherm(View View){
        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.AlertDialogCustom));
        builder.setMessage(R.string.isotherm)
                .setTitle("26 degree isotherm");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.isotherm);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) { mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void modis(View View){
        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.AlertDialogCustom));
        builder.setMessage(R.string.modis)
                .setTitle("MODIS");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.modis);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void displayCarbon(View View){
        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.AlertDialogCustom));
        builder.setMessage(R.string.c_flux)
                .setTitle("Carbon Flux");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.carbonflux);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void displayBlackCarbon(View View){
        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.AlertDialogCustom));
        builder.setMessage(R.string.b_carbon)
                .setTitle("Black Carbon");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.blackcarbon);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void displaySulfateAot(View View){
        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.AlertDialogCustom));
        builder.setMessage(R.string.sulfate)
                .setTitle("Black Carbon and Sulfate AOT");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.carbonaot);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void displayThickness(View View){
        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.AlertDialogCustom));
        builder.setMessage(R.string.thickness)
                .setTitle("Sulfate Optical Thickness");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.thickness);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void displayAcars(View View){
        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.AlertDialogCustom));
        builder.setMessage(R.string.ACARS)
                .setTitle("ACARS");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.acars);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void displayGanymede(View View){
        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.AlertDialogCustom));
        builder.setMessage(R.string.Ganymede)
                .setTitle("Ganymede");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.ganymede);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void displayIo(View View){
        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.AlertDialogCustom));
        builder.setMessage(R.string.io)
                .setTitle("Io");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.io);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void displayCallisto(View View){
        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.AlertDialogCustom));
        builder.setMessage(R.string.Callisto)
                .setTitle("Callisto");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.callisto);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void displayTriton(View View){
        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.AlertDialogCustom));
        builder.setMessage(R.string.triton)
                .setTitle("Triton");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.triton);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

}






