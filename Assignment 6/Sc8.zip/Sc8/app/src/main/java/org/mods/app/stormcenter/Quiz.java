package org.mods.app.stormcenter;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;


/**
 * Created by Matthew on 7/12/2015.
 */
public class Quiz extends Activity  {
    TextView txt1;
    TextView txt2;
    TextView txt3;
    TextView txt4;
    TextView txt5;
    Context context;
    private RadioGroup radioGroupId;
    private RadioButton radioGenderButton;
    RadioButton a1,a2,a3,a4;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz);
        txt1 = (TextView) findViewById(R.id.txt1);
        txt2 = (TextView) findViewById(R.id.txt2);
        txt3 = (TextView) findViewById(R.id.txt3);
        txt4 = (TextView) findViewById(R.id.txt4);
        txt5 = (TextView) findViewById(R.id.txt5);
        context = getApplicationContext();
        //View continueButton = findViewById(R.id.continue_button);
        // continueButton.setOnClickListener(this);
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.a1_1:
                if (checked)
                    txt1.setText("Wrong");
                break;
            case R.id.a1_2:
                if (checked)
                    txt1.setText("Wrong");
                break;
            case R.id.a1_3:
                if (checked)
                    txt1.setText("Correct");
                break;
            case R.id.a1_4:
                if (checked)
                    txt1.setText("Wrong");
                break;

        }


        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.a2_1:
                if (checked)
                    txt2.setText("Correct");
                break;
            case R.id.a2_2:
                if (checked)
                    txt2.setText("Wrong");
                break;
            case R.id.a2_3:
                if (checked)
                    txt2.setText("Wrong");
                break;
            case R.id.a2_4:
                if (checked)
                    txt2.setText("Wrong");
                break;

        }

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.a3_1:
                if (checked)
                    txt3.setText("Wrong");
                break;
            case R.id.a3_2:
                if (checked)
                    txt3.setText("Wrong");
                break;
            case R.id.a3_3:
                if (checked)
                    txt3.setText("Wrong");
                break;
            case R.id.a3_4:
                if (checked)
                    txt3.setText("Correct");
                break;

        }


        switch(view.getId()) {
            case R.id.a4_1:
                if (checked)
                    txt4.setText("Wrong");
                break;
            case R.id.a4_2:
                if (checked)
                    txt4.setText("Correct");
                break;
            case R.id.a4_3:
                if (checked)
                    txt4.setText("Wrong");
                break;
            case R.id.a4_4:
                if (checked)
                    txt4.setText("Wrong");
                break;

        }

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.a5_1:
                if (checked)
                    txt5.setText("Correct");
                break;
            case R.id.a5_2:
                if (checked)
                    txt5.setText("Wrong");
                break;
            case R.id.a5_3:
                if (checked)
                    txt5.setText("Wrong");
                break;
            case R.id.a5_4:
                if (checked)
                    txt5.setText("Wrong");
                break;

        }

    }



    }







