package org.mods.app.stormcenter;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Context;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;


/**
 * Created by Matthew on 7/12/2015.
 */
public class Storminfo extends Activity {
    // flag for Internet connection status
    Boolean isInternetPresent = false;
    // Connection detector class
    ConnectionDetector cd;

    TextView txtV;
    WebView web;
    Button catOne;
    Button catTwo;
    Button catThree;
    Button catFour;
    Button btnStatus;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.storminfo);
        txtV = (TextView) findViewById(R.id.txtV);
        web = (WebView) findViewById(R.id.web);
        catOne= (Button) findViewById(R.id.catone);
        catTwo= (Button) findViewById(R.id.cattwo);
        catThree= (Button) findViewById(R.id.catthree);
        catFour= (Button) findViewById(R.id.catfour);
        btnStatus = (Button) findViewById(R.id.btn_storminf);

        // creating connection detector class instance
        cd = new ConnectionDetector(getApplicationContext());



        /**
         * Check Internet status button click event
         * */
        btnStatus.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                // get Internet status
                isInternetPresent = cd.isConnectingToInternet();

                // check for Internet status
                if (isInternetPresent) {
                    web.setVisibility(View.VISIBLE);
                    web.loadUrl("http://www.nhc.noaa.gov/");
                    txtV.setVisibility(View.INVISIBLE);
                    catOne.setVisibility(View.INVISIBLE);
                    catTwo.setVisibility(View.INVISIBLE);
                    catThree.setVisibility(View.INVISIBLE);
                    catFour.setVisibility(View.INVISIBLE);
                    // Internet Connection is Present
                    // make HTTP requests
                } else {

                    web.setVisibility(View.VISIBLE);
                    web.setVisibility(View.INVISIBLE);
                    txtV.setVisibility(View.INVISIBLE);
                    catOne.setVisibility(View.INVISIBLE);
                    catTwo.setVisibility(View.INVISIBLE);
                    catThree.setVisibility(View.INVISIBLE);
                    catFour.setVisibility(View.INVISIBLE);
                    // Internet connection is not present
                    // Ask user to connect to Internet
                    showAlertDialog(Storminfo.this, "No Internet Connection",
                            "Please connect to the internet to access this page.", false);
                }
            }

        });



    }


    /**
     * Function to display simple Alert Dialog
     * @param context - application context
     * @param title - alert dialog title
     * @param message - alert message
     * @param status - success/failure (used to set icon)
     * */
    public void showAlertDialog(Context context, String title, String message, Boolean status) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();

        // Setting Dialog Title
        alertDialog.setTitle(title);

        // Setting Dialog Message
        alertDialog.setMessage(message);

        // Setting alert dialog icon
        alertDialog.setIcon((status) ? R.drawable.mods1 : R.drawable.nowifi);

        // Setting OK Button
        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        // Showing Alert Message
        alertDialog.show();
    }

    public void scale(View view){
        txtV.setVisibility(View.INVISIBLE);
        //txtV.setText(R.string.cat_1);
        //catOne.setText("Category 1");
        web.setVisibility(View.INVISIBLE);
        catOne.setVisibility(View.VISIBLE);
        catTwo.setVisibility(View.VISIBLE);
        catThree.setVisibility(View.VISIBLE);
        catFour.setVisibility(View.VISIBLE);
    }
    public void Answer (View view){
        web.setVisibility(View.VISIBLE);
        web.loadUrl("http://www.nhc.noaa.gov/");
        txtV.setVisibility(View.INVISIBLE);
        catOne.setVisibility(View.INVISIBLE);
        catTwo.setVisibility(View.INVISIBLE);
        catThree.setVisibility(View.INVISIBLE);
        catFour.setVisibility(View.INVISIBLE);
    }
    public void check (View view){
        txtV.setVisibility(View.VISIBLE);
        txtV.setText(R.string.during);
        web.setVisibility(View.INVISIBLE);
        catOne.setVisibility(View.INVISIBLE);
        catTwo.setVisibility(View.INVISIBLE);
        catThree.setVisibility(View.INVISIBLE);
        catFour.setVisibility(View.INVISIBLE);
    }
    public void versus (View View){
        txtV.setVisibility(View.VISIBLE);
        //(View.VISIBLE);
        txtV.setText(R.string.versus);
        web.setVisibility(View.INVISIBLE);
       catOne.setVisibility(View.INVISIBLE);
       catTwo.setVisibility(View.INVISIBLE);
       catThree.setVisibility(View.INVISIBLE);
       catFour.setVisibility(View.INVISIBLE);
    }





    public void oneDialog(View View){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.cat_1)
                .setTitle("Category One");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.cat1);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void twoDialog(View View){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.cat_2)
                .setTitle("Category Two");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.cat2);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void threeDialog(View View){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.cat_3)
                .setTitle("Category Three");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.cat3);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void fourDialog(View View){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.cat_45)
                .setTitle("Category Four/Five");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.cat4);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}