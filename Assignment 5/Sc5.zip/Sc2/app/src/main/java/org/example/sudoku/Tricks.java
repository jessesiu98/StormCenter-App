package org.example.sudoku;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.app.AlertDialog;
import android.view.MenuItem;
import android.content.DialogInterface;
import android.content.Context;

import static android.app.AlertDialog.*;


/**
 * Created by Matthew on 7/12/2015.
 */
public class Tricks extends Activity  {
    Context context;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tricks);
        context = getApplicationContext();
        //View continueButton = findViewById(R.id.continue_button);
       // continueButton.setOnClickListener(this);
    }

    public void windTest( View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.photo_op_text)
              .setTitle("Wind Photo Opportunity");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.test);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();

    }
    public void funFact ( View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.fun_text)
                .setTitle("Hurricane simulator fun fact");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.test);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();

    }
    public void plasmaTrick ( View view){
         final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.ptrick_text)
                .setTitle("Plasma Ball Fun Fact");
         final MediaPlayer mp = MediaPlayer.create(this, R.raw.test);
         builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
             public void onClick(DialogInterface dialog, int id) {
                 mp.start();
             }
         });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    //public void setButtons(){

    }



