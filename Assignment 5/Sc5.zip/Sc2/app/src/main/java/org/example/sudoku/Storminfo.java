package org.example.sudoku;

import android.os.Bundle;
import android.app.Activity;

import static org.example.sudoku.R.layout.storminfo;

/**
 * Created by Matthew on 7/12/2015.
 */
public class Storminfo extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.storminfo);
    }
}
