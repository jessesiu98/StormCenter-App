package org.example.sudoku;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.app.Activity;
/**
 * Created by Matthew on 7/10/2015.
 */
public class Plasma extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.plasmaball);
    }

    public void displaySafety(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.safety_text)
                .setTitle("Plasma Ball Safety");
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void displayAbout(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.about_plasma)
                .setTitle("About the Plasma Ball");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.test);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void displayWorks(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.works_plasma)
                .setTitle("So, what exactly happens?");
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.test);
        builder.setPositiveButton("Audio", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                mp.start();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}



