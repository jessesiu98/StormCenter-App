package org.example.sudoku;
import android.os.Bundle;
import android.app.Activity;
/**
 * Created by Matthew on 7/13/2015.
 */
public class Omniglobe extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.omniglobe);
    }
}

